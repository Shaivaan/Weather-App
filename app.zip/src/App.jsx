import React from 'react';
import './App.css';
import { Main } from './Components/Main';
import dotenv from  'dotenv'
function App() {

 

  return (
    <Main/>
  );
}

export default App;
