export const ADD_COR = "ADD_COR";
export const addCor = (payload)=>{
    return {type:ADD_COR,payload};
}

export const ADD_MAP = "ADD_MAP";
export const addMap =(payload)=>{
    return {type:ADD_MAP,payload};
}

export const ADD_TEMP = "ADD_TEMP";
export const addTemp = (payload)=>{
    return {type:ADD_TEMP,payload}
}

export const CUR_DAY = "CUR_DAY";
export const curDay = (payload)=>{
    return {type:CUR_DAY,payload};
}