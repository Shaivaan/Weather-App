import React from 'react'

export const SearchCard=({city,state})=> {
  return (
    <>
    <div className='city'>
      <h3>ㅤ  {city}, {state} </h3>
    </div>
    </>
  )
}


