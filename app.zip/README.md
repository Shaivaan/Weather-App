<h1><i>Weather App(Solo Project)</i></h1>
<p><i>Weather app which shows the information of weather, temperature, humidity ,sunrise and sunset for mostly all of the location in India including location access functionality which shows the user location's weather.</i></p>

<h3><i>Tech Stacks</h3></i>
<ul>
  <li>React</li>
  <li>HTML</li>
  <li>CSS</li>
  <li>Weather Api</li>
  <li>Apex Charts</li>
  <li>Google Maps</li>
</ul>

<img src = "https://user-images.githubusercontent.com/93570605/175881304-a570b272-9ddd-4936-bbec-10cb12f4b4ab.png" />

<h2><i>Components</i></h2>
<br/>
<h2><i>8 Days Data</i></h2>
<p><i>These data contains every information regarding temperature, humidity, sunset and sunrise on that day.User just have to click on particular day.</i></p>

<img src = "https://user-images.githubusercontent.com/93570605/175880832-0048b96c-8d02-4569-98c5-3ae7a30a0175.png" />
<br/>

<h2><i>Charts for Each Day</i></h2>
<p><i>This is area graph representation for the for the temperature throught that day.</i></p>
<h2>Axis</h2>
<ul>
  <li>X-Axis:Period</li>
  <li>Y-Axis:Temperature(in °C)</li>
</ul>

<img src = "https://user-images.githubusercontent.com/93570605/175880771-27524374-9688-40b3-a159-cf01316802ce.png" />


<h2><i>Map(Google)</i></h2>
<p><i>Provide a representation of selected area via map.</i></p>

<img src = "https://user-images.githubusercontent.com/93570605/175880807-086e7d4a-de44-4870-abe6-a2f2d4d94214.png" />
